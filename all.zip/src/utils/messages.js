const config = require('../config');
const { formatPrice } = require('./keyboard');

function safeName(name) {
    return String(name || 'bạn').replace(/[<&>]/g, '');
}

const messages = {
    welcome: (name) =>
        `👋 <b>CHÀO MỪNG ĐẾN ${config.SHOP_NAME.toUpperCase()}</b>\n\n` +
        `🔑 <b>SHOP KEY TỰ ĐỘNG</b>\n` +
        `⚡ Giao key nhanh • Giá rõ ràng • Hỗ trợ 24/7\n\n` +
        `Xin chào <b>${safeName(name)}</b> 👋\n` +
        `Chọn chức năng bên dưới để bắt đầu mua key.`,

    home: (user, stats = {}) =>
        `🛍️ <b>${config.SHOP_NAME.toUpperCase()}</b>\n` +
        `━━━━━━━━━━━━━━━━━━\n` +
        `🔑 <b>SHOP KEY TỰ ĐỘNG 24/7</b>\n\n` +
        `👤 Khách hàng: <b>${safeName(user.full_name)}</b>\n` +
        `💰 Số dư: <b>${formatPrice(user.balance)}</b>\n` +
        `📦 Sản phẩm: <b>${stats.products ?? '—'}</b>\n` +
        `━━━━━━━━━━━━━━━━━━\n` +
        `✨ Chọn <b>Cửa hàng</b> để xem mặt hàng và thời hạn.`,

    accountInfo: (user) =>
        `👤 <b>TÀI KHOẢN</b>\n` +
        `━━━━━━━━━━━━━━━━━━\n` +
        `🆔 ID: <code>${user.telegram_id}</code>\n` +
        `👤 Tên: <b>${safeName(user.full_name)}</b>\n` +
        `💰 Số dư: <b>${formatPrice(user.balance)}</b>\n` +
        `📅 Tham gia: ${user.created_at}`,

    productHeader:
        `🛒 <b>DANH SÁCH MẶT HÀNG</b>\n` +
        `━━━━━━━━━━━━━━━━━━\n` +
        `Chọn loại key bạn muốn mua 👇`,

    categoryHeader: (category) =>
        `${category.emoji || '📦'} <b>${category.name.toUpperCase()}</b>\n` +
        `━━━━━━━━━━━━━━━━━━\n` +
        `Chọn thời hạn / mặt hàng bên dưới 👇`,

    selectQuantity: (product) => {
        const stock = Number(product.display_stock ?? product.stock_count ?? 0);
        const duration = product.duration_days ? `⏱ Thời hạn: <b>${product.duration_days} ngày</b>\n` : '';
        return (
            `🔑 <b>${product.name}</b>\n` +
            `━━━━━━━━━━━━━━━━━━\n` +
            duration +
            `💵 Đơn giá: <b>${formatPrice(product.price)}</b>\n` +
            `📦 Còn hàng: <b>${stock}</b>\n\n` +
            `🛒 <b>CHỌN SỐ LƯỢNG</b>\n` +
            `Chọn số key bạn muốn mua:`
        );
    },

    contactOnly: (product) =>
        `🔑 <b>${product.name}</b>\n\n` +
        `💵 Giá: <b>${formatPrice(product.price)}</b>\n` +
        `💬 Mặt hàng này cần liên hệ admin để xử lý.\n\n` +
        `Bấm nút bên dưới để liên hệ.`,

    paymentQR: (order, product, paymentCode) =>
        `💳 <b>THANH TOÁN ĐƠN #${order.id}</b>\n` +
        `━━━━━━━━━━━━━━━━━━\n` +
        `🔑 ${product.name}\n` +
        `🔢 Số lượng: <b>${order.quantity}</b>\n` +
        `💰 Tổng tiền: <b>${formatPrice(order.total_price)}</b>\n\n` +
        `🏦 Quét QR phía trên để chuyển khoản.\n` +
        `📝 Nội dung: <code>${paymentCode}</code>\n\n` +
        `⚠️ Giữ nguyên nội dung chuyển khoản để đơn được đối soát.`,

    orderSuccess: (product, quantity, accounts) => {
        let msg =
            `✅ <b>MUA KEY THÀNH CÔNG</b>\n` +
            `━━━━━━━━━━━━━━━━━━\n` +
            `🔑 ${product.name}\n` +
            `🔢 Số lượng: <b>${quantity}</b>\n\n` +
            `📦 <b>KEY / DỮ LIỆU:</b>\n`;
        accounts.forEach((acc, i) => {
            msg += `\n<b>${i + 1}.</b> <code>${String(acc)}</code>`;
        });
        return msg;
    },

    orderSuccessNotify: (quantity) =>
        `✅ Đã xử lý thành công <b>${quantity}</b> key. Thông tin giao hàng ở tin nhắn tiếp theo.`,

    noStock: '⛔ <b>SẢN PHẨM HẾT HÀNG</b>\nVui lòng chọn mặt hàng khác.',
    invalidQuantity: (available) =>
        `⛔ Không đủ hàng. Hiện chỉ còn <b>${available}</b> key.`,

    napInfo: (amount, paymentCode) =>
        `💳 <b>NẠP TIỀN</b>\n━━━━━━━━━━━━━━━━━━\n` +
        `💰 Số tiền: <b>${formatPrice(amount)}</b>\n` +
        `📝 Nội dung: <code>${paymentCode}</code>\n\n` +
        `Quét QR phía trên và giữ nguyên nội dung chuyển khoản.`,

    checkPayStatus: (order) => {
        const statusMap = {
            pending: '⏳ Chờ thanh toán',
            paid: '💳 Đã thanh toán',
            delivered: '✅ Đã giao key',
            cancelled: '❌ Đã hủy',
        };
        return (
            `🧾 <b>ĐƠN #${order.id}</b>\n` +
            `🔑 ${order.product_name}\n` +
            `🔢 SL: <b>${order.quantity}</b>\n` +
            `💰 ${formatPrice(order.total_price)}\n` +
            `📌 ${statusMap[order.status] || order.status}\n` +
            `📅 ${order.created_at}`
        );
    },

    supportInfo:
        `🆘 <b>HỖ TRỢ KHÁCH HÀNG</b>\n` +
        `━━━━━━━━━━━━━━━━━━\n` +
        `Gặp vấn đề khi mua key hoặc thanh toán?\n\n` +
        `👨‍💻 Admin: <b>${config.SUPPORT_CONTACT}</b>\n` +
        `⏰ Hỗ trợ 24/7`,

    myId: (id) => `🆔 Telegram ID: <code>${id}</code>`,
    adminOnly: '⛔ Bạn không có quyền sử dụng chức năng này.',
    orderCancelled: '❌ Đơn hàng đã được hủy.',
    paymentPending: '⏳ Đơn đang chờ xác nhận thanh toán. Vui lòng chờ admin xử lý.',
};

module.exports = messages;
