const { Markup } = require('telegraf');

function productListKeyboard(products) {
    const buttons = [];
    for (let i = 0; i < products.length; i += 2) {
        const row = [];
        for (let j = i; j < Math.min(i + 2, products.length); j++) {
            const p = products[j];
            const stock = Number(p.display_stock ?? p.stock_count ?? 0);
            const duration = p.duration_days ? ` • ${p.duration_days} ngày` : '';
            const status = stock > 0 ? `📦 ${stock}` : '⛔ Hết';
            row.push(Markup.button.callback(
                `${p.emoji || '🔑'} ${p.name}${duration}\n💰 ${formatPrice(p.price)} • ${status}`,
                `product_${p.id}`
            ));
        }
        buttons.push(row);
    }
    buttons.push([
        Markup.button.callback('🔄 Làm mới', 'refresh_products'),
        Markup.button.callback('🏠 Trang chủ', 'home_menu')
    ]);
    return Markup.inlineKeyboard(buttons);
}

function categoryKeyboard(categories) {
    const buttons = [];
    for (let i = 0; i < categories.length; i += 2) {
        const row = [];
        for (let j = i; j < Math.min(i + 2, categories.length); j++) {
            const c = categories[j];
            row.push(Markup.button.callback(
                `${c.emoji || '📦'} ${c.name}`,
                `cat_${c.id}`
            ));
        }
        buttons.push(row);
    }
    buttons.push([Markup.button.callback('🏠 Trang chủ', 'home_menu')]);
    return Markup.inlineKeyboard(buttons);
}

function quantityKeyboard(productId, maxQty = 10) {
    const max = Math.max(1, Math.min(Number(maxQty) || 1, 10));
    const rows = [];
    for (let i = 1; i <= max; i += 5) {
        const row = [];
        for (let q = i; q < Math.min(i + 5, max + 1); q++) {
            row.push(Markup.button.callback(`× ${q}`, `qty_${productId}_${q}`));
        }
        rows.push(row);
    }
    rows.push([
        Markup.button.callback('↩️ Danh sách', 'refresh_products'),
        Markup.button.callback('🏠 Trang chủ', 'home_menu')
    ]);
    return Markup.inlineKeyboard(rows);
}

function orderConfirmKeyboard(orderId) {
    return Markup.inlineKeyboard([
        [Markup.button.callback('✅ Đã chuyển khoản', `check_paid_${orderId}`)],
        [Markup.button.callback('❌ Hủy đơn', `cancel_order_${orderId}`)],
    ]);
}

function postDeliveryKeyboard() {
    return Markup.inlineKeyboard([
        [
            Markup.button.callback('🛒 Mua tiếp', 'buy_again'),
            Markup.button.callback('👤 Tài khoản', 'account_main')
        ],
        [Markup.button.callback('🏠 Trang chủ', 'home_menu')],
    ]);
}

function mainMenuKeyboard() {
    return Markup.keyboard([
        ['🛒 Cửa hàng', '💳 Nạp tiền'],
        ['🧾 Lịch sử', '👤 Tài khoản'],
        ['🆘 Hỗ trợ'],
    ]).resize().persistent();
}

function formatPrice(amount) {
    return new Intl.NumberFormat('vi-VN').format(Number(amount) || 0) + 'đ';
}

module.exports = {
    productListKeyboard,
    categoryKeyboard,
    quantityKeyboard,
    orderConfirmKeyboard,
    postDeliveryKeyboard,
    formatPrice,
    mainMenuKeyboard,
};
