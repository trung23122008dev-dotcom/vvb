const productService = require('../services/productService');
const messages = require('../utils/messages');
const { productListKeyboard, categoryKeyboard } = require('../utils/keyboard');

module.exports = (bot) => {
    bot.command('product', (ctx) => sendShop(ctx));

    bot.action('refresh_products', (ctx) => {
        ctx.answerCbQuery('🔄 Đã làm mới');
        sendShop(ctx, true);
    });

    bot.action(/^cat_(\d+)$/, (ctx) => {
        const category = productService.getCategories().find(c => Number(c.id) === Number(ctx.match[1]));
        if (!category) return ctx.answerCbQuery('⛔ Danh mục không tồn tại');
        const products = productService.getByCategory(category.id);
        if (!products.length) return ctx.answerCbQuery('⛔ Danh mục đang trống');
        ctx.answerCbQuery();
        ctx.replyWithHTML(messages.categoryHeader(category), productListKeyboard(products));
    });

    bot.action('shop_categories', (ctx) => {
        ctx.answerCbQuery();
        sendShop(ctx);
    });
};

function sendShop(ctx, edit = false) {
    const products = productService.getAll();
    const categories = productService.getCategories().filter(c =>
        products.some(p => Number(p.category_id) === Number(c.id))
    );

    if (!categories.length) {
        const msg = '⛔ <b>SHOP ĐANG TRỐNG</b>\nChưa có mặt hàng nào được mở bán.';
        return edit ? ctx.editMessageText(msg, { parse_mode: 'HTML' }) : ctx.replyWithHTML(msg);
    }

    const opts = categoryKeyboard(categories);
    if (edit) {
        return ctx.editMessageText(messages.productHeader, {
            parse_mode: 'HTML',
            ...opts
        });
    }
    ctx.replyWithHTML(messages.productHeader, opts);
}
