const userService = require('../services/userService');
const productService = require('../services/productService');
const messages = require('../utils/messages');
const { mainMenuKeyboard } = require('../utils/keyboard');

module.exports = (bot) => {
    bot.start((ctx) => {
        const user = userService.findOrCreate(ctx.from);
        const stats = { products: productService.getAll().length };
        ctx.replyWithHTML(messages.welcome(user.full_name), mainMenuKeyboard());
        ctx.replyWithHTML(messages.home(user, stats), mainMenuKeyboard());
    });
};
