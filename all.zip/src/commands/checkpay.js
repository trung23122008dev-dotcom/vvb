const orderService = require('../services/orderService');
const messages = require('../utils/messages');
const { Markup } = require('telegraf');

module.exports = (bot) => {
    bot.command('checkpay', showHistory);
    bot.hears('🧾 Lịch sử', showHistory);

    bot.action('history_main', (ctx) => {
        ctx.answerCbQuery();
        showHistory(ctx);
    });

    function showHistory(ctx) {
        const orders = orderService.getRecentByUser(ctx.from.id, 10);
        if (!orders.length) {
            return ctx.replyWithHTML(
                `🧾 <b>LỊCH SỬ ĐƠN HÀNG</b>\n━━━━━━━━━━━━━━━━━━\nChưa có đơn hàng nào.`,
                Markup.inlineKeyboard([[Markup.button.callback('🛒 Mua key', 'shop_main')]])
            );
        }
        let text = `🧾 <b>LỊCH SỬ ĐƠN HÀNG</b>\n━━━━━━━━━━━━━━━━━━\n\n`;
        orders.forEach((o) => {
            text += messages.checkPayStatus(o) + '\n\n';
        });
        ctx.replyWithHTML(text, Markup.inlineKeyboard([
            [Markup.button.callback('🛒 Mua tiếp', 'shop_main')],
            [Markup.button.callback('🏠 Trang chủ', 'home_menu')],
        ]));
    }
};
