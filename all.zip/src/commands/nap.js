const paymentService = require('../services/paymentService');
const userService = require('../services/userService');
const messages = require('../utils/messages');
const { formatPrice, Markup } = require('../utils/keyboard');

module.exports = (bot) => {
    bot.command('nap', handleTopup);
    bot.action('topup_main', (ctx) => {
        ctx.answerCbQuery();
        ctx.replyWithHTML(
            `💳 <b>NẠP SỐ DƯ</b>\n\nNhập số tiền muốn nạp, ví dụ:\n<code>/nap 50000</code>\n\n💡 Tối thiểu 10.000đ`,
            Markup.inlineKeyboard([[Markup.button.callback('🏠 Trang chủ', 'home_menu')]])
        );
    });

    bot.hears('💳 Nạp tiền', handleTopupInfo);

    function handleTopup(ctx) {
        const parts = ctx.message.text.trim().split(/\s+/);
        if (parts.length < 2 || !/^\d+$/.test(parts[1])) return handleTopupInfo(ctx);
        const amount = parseInt(parts[1]);
        if (amount < 10000) return ctx.reply('⛔ Số tiền nạp tối thiểu là 10.000đ.');

        userService.findOrCreate(ctx.from);
        const payment = paymentService.generatePayment(amount);

        return ctx.replyWithPhoto(payment.qrUrl, {
            caption: messages.napInfo(amount, payment.paymentCode),
            parse_mode: 'HTML',
            ...Markup.inlineKeyboard([[Markup.button.callback('🏠 Trang chủ', 'home_menu')]])
        });
    }

    function handleTopupInfo(ctx) {
        ctx.replyWithHTML(
            `💳 <b>NẠP SỐ DƯ</b>\n` +
            `━━━━━━━━━━━━━━━━━━\n` +
            `Nhập lệnh theo mẫu:\n<code>/nap 50000</code>\n\n` +
            `💡 Tối thiểu: <b>10.000đ</b>`
        );
    }
};
