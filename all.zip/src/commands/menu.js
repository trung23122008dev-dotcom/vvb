const userService = require('../services/userService');
const productService = require('../services/productService');
const messages = require('../utils/messages');
const { mainMenuKeyboard } = require('../utils/keyboard');
const { Markup } = require('telegraf');

module.exports = (bot) => {
    bot.command('menu', (ctx) => showHome(ctx));

    bot.action('home_menu', (ctx) => {
        ctx.answerCbQuery();
        showHome(ctx, true);
    });

    bot.action('account_main', (ctx) => {
        ctx.answerCbQuery();
        const user = userService.findOrCreate(ctx.from);
        ctx.replyWithHTML(messages.accountInfo(user), Markup.inlineKeyboard([
            [Markup.button.callback('🛒 Cửa hàng', 'shop_main')],
            [Markup.button.callback('🏠 Trang chủ', 'home_menu')],
        ]));
    });

    bot.action('shop_main', (ctx) => {
        ctx.answerCbQuery();
        const products = productService.getAll();
        const { categoryKeyboard } = require('../utils/keyboard');
        const categories = productService.getCategories().filter(c =>
            products.some(p => Number(p.category_id) === Number(c.id))
        );
        if (!categories.length) return ctx.reply('⛔ Hiện chưa có mặt hàng.');
        ctx.replyWithHTML(messages.productHeader, categoryKeyboard(categories));
    });

    function showHome(ctx, edit = false) {
        const user = userService.findOrCreate(ctx.from);
        const stats = { products: productService.getAll().length };
        if (edit && ctx.callbackQuery) {
            return ctx.editMessageText(messages.home(user, stats), {
                parse_mode: 'HTML',
                ...Markup.inlineKeyboard([
                    [Markup.button.callback('🛒 Cửa hàng', 'shop_main')],
                    [Markup.button.callback('💳 Nạp tiền', 'topup_main')],
                    [Markup.button.callback('🧾 Lịch sử', 'history_main'), Markup.button.callback('👤 Tài khoản', 'account_main')],
                    [Markup.button.callback('🆘 Hỗ trợ', 'support_main')],
                ])
            });
        }
        ctx.replyWithHTML(messages.home(user, stats), mainMenuKeyboard());
    }
};
