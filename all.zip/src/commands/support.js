const messages = require('../utils/messages');
const { Markup } = require('telegraf');
const config = require('../config');

module.exports = (bot) => {
    bot.command('support', showSupport);
    bot.hears('🆘 Hỗ trợ', showSupport);
    bot.action('support_main', (ctx) => {
        ctx.answerCbQuery();
        showSupport(ctx);
    });

    function showSupport(ctx) {
        const username = String(config.SUPPORT_CONTACT || '').replace('@', '');
        ctx.replyWithHTML(messages.supportInfo, Markup.inlineKeyboard([
            [Markup.button.url('💬 Nhắn Admin', `https://t.me/${username}`)],
            [Markup.button.callback('🏠 Trang chủ', 'home_menu')],
        ]));
    }
};
