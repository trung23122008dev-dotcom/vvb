# Nguyễn Trung Key Shop Bot

Bot Telegram bán key theo mô hình:

**Danh sách mặt hàng → chọn thời hạn (1/7/30 ngày hoặc tùy chỉnh) → chọn số lượng → QR thanh toán → admin xác nhận/giao key.**

## Chạy bot

```bash
npm install
cp .env.example .env
npm start
```

## Thêm mặt hàng

```text
/addproduct catID | tên | giá | số_ngày
```

Ví dụ:

```text
/addproduct 1 | TrollModz | 30000 | 1
/addproduct 1 | TrollModz | 70000 | 7
/addproduct 1 | TrollModz | 150000 | 30
```

Sau đó thêm key vào kho:

```text
/addstock ID
```

Gửi mỗi key một dòng.

## Giao diện khách

- 🛒 Cửa hàng
- 💳 Nạp tiền
- 🧾 Lịch sử
- 👤 Tài khoản
- 🆘 Hỗ trợ

Phần khách đã bỏ các nội dung không cần thiết như `/myid` khỏi menu bot.

## Lưu ý

File `.env` và database cũ không được đóng gói để tránh làm lộ token, tài khoản ngân hàng hoặc dữ liệu kho. Database mới sẽ tự tạo khi bot chạy.
